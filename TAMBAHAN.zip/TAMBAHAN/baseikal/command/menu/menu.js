const menu =  ` 
° Owner  : HW MODS WA
° Version : 15
° Baileys : 5.0.0

┏━┳┳┳━┳┳┓
┃━┫┃┃┏┫━┫┏┓
┃┏┫┃┃┗┫┃┃┃┃
┗┛┗━┻━┻┻┛┃┃
┏┳┳━┳┳┳┓┏┫┣┳┓
┃┃┃┃┃┃┃┃┣┻┫┃┃
┣┓┃┃┃┃┣┫┃┏┻┻┫
┗━┻━┻━┻
*Menu Fun*
┏━━⊱
┣❏ Jadian
┣❏ Artinama
┣❏ Artimimpi
┣❏ Kecocokanpasangan
┣❏ Kecocokannama
┣❏ Jadianpernikahan
┣❏ Rejeki
┣❏ Sifatusaha
┣❏ Pekerjaan
┣❏ Artitarot
┣❏ Potensipenyakit
┣❏ Ramalannasib
┣❏ Harisangar
┣❏ Haribaik
┣❏ Fengshui
┣❏ Nagahari
┣❏ Harinaas
┣❏ Weton
┣❏ Peruntungan
┣❏ Arahrejeki
┣❏ Sifat
┣❏ Keberuntungan
┣❏ Memancing
┣❏ Masasubur
┣❏ Zodiak
┣❏ Shio
┗━━⊱
 ▰▱▰▱▰▱▰▱▰▱▰▱▰▱`
exports.menu = menu