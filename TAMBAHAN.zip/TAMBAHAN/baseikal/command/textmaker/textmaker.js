const textmaker =  ` 
┏━┳┳┳━┳┳┓
┃━┫┃┃┏┫━┫┏┓
┃┏┫┃┃┗┫┃┃┃┃
┗┛┗━┻━┻┻┛┃┃
┏┳┳━┳┳┳┓┏┫┣┳┓
┃┃┃┃┃┃┃┃┣┻┫┃┃
┣┓┃┃┃┃┣┫┃┏┻┻┫
┗━┻━┻━┻
contoh :
candy haikal
┏━━⊱
┣❏ candy 
┣❏ christmas 
┣❏ 3dchristmas 
┣❏ sparklechristmas
┣❏ deepsea 
┣❏ scifi 
┣❏ rainbow 
┣❏ waterpipe 
┣❏ spooky 
┣❏ pencil 
┣❏ circuit 
┣❏ discovery 
┣❏ metalic 
┣❏ fiction 
┣❏ demon 
┣❏ transformer 
┣❏ berry 
┣❏ thunder 
┣❏ magma 
┣❏ 3dstone 
┣❏ neonlight 
┣❏ glitch 
┣❏ harrypotter 
┣❏ brokenglass
┣❏ papercut 
┣❏ watercolor
┣❏ multicolor 
┣❏ neondevil 
┣❏ underwater 
┣❏ graffitibike
┣❏ snow 
┣❏ cloud 
┣❏ honey 
┣❏ ice 
┣❏ fruitjuice 
┣❏ biscuit 
┣❏ wood 
┣❏ chocolate 
┣❏ strawberry 
┣❏ matrix 
┣❏ blood 
┣❏ dropwater 
┣❏ toxic 
┣❏ lava 
┣❏ rock 
┣❏ bloodglas 
┣❏ hallowen 
┣❏ darkgold 
┣❏ joker 
┣❏ wicker
┣❏ firework 
┣❏ skeleton 
┣❏ blackpink 
┣❏ sand 
┣❏ glue 
┣❏ 1917 
┣❏ leaves
┣❏ transformer
┣❏ herryp
┣❏ neondevil
┣❏ 3dstone
┣❏ thunder
┣❏ graffiti
┣❏ glitch3
┣❏ 3dbox
┣❏ drapwater
┣❏ lion2
┣❏ papercut
┣❏
┗━━⊱[ HW MODS WA ]`
exports.textmaker = textmaker