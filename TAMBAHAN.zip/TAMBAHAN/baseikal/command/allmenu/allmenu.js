const allmenu =  ` 
┏━┳┳┳━┳┳┓
┃━┫┃┃┏┫━┫┏┓
┃┏┫┃┃┗┫┃┃┃┃
┗┛┗━┻━┻┻┛┃┃
┏┳┳━┳┳┳┓┏┫┣┳┓
┃┃┃┃┃┃┃┃┣┻┫┃┃
┣┓┃┃┃┃┣┫┃┏┻┻┫
┗━┻━┻━┻
*Random*
┏━━⊱
┣❏kalkulator
┣❏toimage
┣❏toonce
┣❏tomp4
┣❏tovn
┣❏togif
┣❏tourl 
┣❏toaud
┣❏sticker
┣❏stickergif
┣❏emojimix
┣❏emojimix2
┣❏smeme
┣❏ktpmaker
┣❏afk
┣❏* [ reply ]
┣❏getname [ reply ]
┣❏getpic [ reply ]
┣❏infochat
┣❏q [ reply ]
┣❏del [ reply ]
┣❏style [ text nya ]
┣❏ss [link nya]
┣❏penjara [ reply ]
┗━━⊱[ HW MOds Wa]`
exports.allmenu = allmenu